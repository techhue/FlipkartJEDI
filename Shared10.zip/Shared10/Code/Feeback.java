Sahaj Jain5:36 PM
yes
Shivansh Arora5:36 PM
Yes
Vamshi Malreddy5:36 PM
Yu
Atif Ashhar5:36 PM
yes
Milan Jain5:36 PM
yes
Jatin Sharma5:36 PM
yes
Bibhudatta Panigrahi5:36 PM
yes
Shivnandan Mandal5:36 PM
yes
Neeramitra Reddy5:36 PM
yes
Akash Agarwal5:36 PM
yes
Saurav Anand5:36 PM
ys
Mohit Dhaka5:36 PM
yes
Dixit Kumar Jain5:37 PM
screen is not visible?
yes
Arjun Dhar5:37 PM
yes
Atif Ashhar5:37 PM
yes
Ankit Kumar5:37 PM
yes
Amit Rai5:37 PM
yes
Prakhar Agarwal5:41 PM
If a stream is infinite, how does it operate internally as it is not possible to store infinite big integers
yes
okay sir
Neeramitra Reddy5:42 PM
Thanks a lot for this training sir
Disha Goyal5:42 PM
Thanks for the training sir
Neeramitra Reddy5:42 PM
Was very insightful
Shishir Agrawal5:42 PM
Just Awesome!
Dishita Malav5:42 PM
it was really good!
Manish Kumar Jagnani5:42 PM
great
Dilip Suthar5:42 PM
awesome
Ayan Zunaid5:42 PM
interesting 
Pranav Mangal5:42 PM
awesome
Ankit Solanki5:42 PM
very cool
Pranjal Tripathi5:42 PM
Awesomee
Anirudh Goel5:42 PM
The way of thinking changed
Jatin Sharma5:42 PM
great
Anil Bansal5:42 PM
Really awesome
Shivnandan Mandal5:42 PM
Awesome!!
Mooizz5:42 PM
Awesome
Vivek Rathi5:42 PM
Awesome 
Shikhar Dhawale5:42 PM
great
Hardik Katyal5:42 PM
Insightful
Ankit Anvesh5:42 PM
awesome
Kritagya Agarwal5:42 PM
Much Needed one 
Atif Ashhar5:42 PM
Great
Mirza Azhar Wasim5:42 PM
awesome
Bibhudatta Panigrahi5:42 PM
thought provoking
Aniket Kumar5:42 PM
awesome
Amit Rai5:42 PM
very helpful and interesting
Harshit Mahajan5:42 PM
Great
Milan Jain5:42 PM
awesome
Prateek Soni5:42 PM
Great
Sahaj Bamba5:42 PM
great
Saarthak Jain5:42 PM
very good sir
Vamshi Malreddy5:42 PM
Very good
Amit Rai5:42 PM
awesome
Mohit Dhaka5:42 PM
 awesome
Arjun Dhar5:42 PM
Amazing
Ankit Kumar5:42 PM
insightful
Narayan G5:42 PM
Great
Disha Goyal5:42 PM
The training was though provoking
Aman Yadav5:42 PM
great
pushpendra kumar5:42 PM
very insightful and awesome
a.j. hrishikesh5:42 PM
noice
Kapil Pathak5:42 PM
it was awesome and concept covered in depth
Rahul Jha5:42 PM
Awesome. 
Vivek Chahar5:42 PM
Insightful
Aman Gupta5:42 PM
Learnt a lot of insightful things
Shreyas Patel5:42 PM
Gave much needed fundamental knowledge
Samriddhi Arya5:42 PM
Thanks for the training sir. It was amazing!!
Ambati Sashidhar cs17b0395:42 PM
Unlearning and relearning was awesome
Shivansh Arora5:42 PM
learnt a great about things to keep in mind for system design
Karan Lamba5:42 PM
very insightful
Saurav Anand5:42 PM
different but great
Srivastav Pratikmohan Chandramohan5:43 PM
Very informative and inspiring
VEERAMAKALI VIGNESH MANIVANNAN5:43 PM
Got a very differeent perspective of looking at codes 
Prakhar Agarwal5:43 PM
Appreciating the way, concepts were given priority...
Neeramitra Reddy5:43 PM
Made me realize that basics and fundamentals were practically non existant before this training
Sahaj Jain5:43 PM
The training was very nice. Explored a lot of new things with a unique perspective. I agree that the training was quite exhaustive but I believe it will help in our future.
Shishir Agrawal5:43 PM
Gave an insight to System Design Thinking in best possible way
Bhumika Saxena5:43 PM
Thank you so much for this training. I learnt a lot many new things!
Mudreka Arif5:43 PM
Disturbed us ;p
Thanks for the training, very insightful
MOHAMMED KHANDWAWALA ee16b1175:44 PM
Very insightful
Harshavardhana Shrirup5:44 PM
Awesome
Yasharth Bajpai5:44 PM
Very Insightful.
Sarthak Koherwal 2K17 CO 3045:44 PM
Enjoyed it
Milind jain5:44 PM
great
Dixit Kumar Jain5:44 PM
amazing me think beyond code
Akash Agarwal5:44 PM
It was really  great and insightful
Sashrika Kaur5:44 PM
Different perspective of programming and a deeper understanding of concepts!
Ramprasad Killari5:44 PM
Realised there's very much to learn which I thought I knew before this training
Rituraj Roy5:44 PM
fundamentals got cleared very well
Vaibhav Sharma5:44 PM
a movie with boring start mind bending ending
Mooizz5:44 PM
 Many concepts are clear now
Dixit Kumar Jain5:44 PM
provokes to think beyond languages
and focus on basics
Lovesh Gupta5:45 PM
i thought I understood java before 
I do understand some of it now 
Datta Tammireddi5:45 PM
Made me think more of design now