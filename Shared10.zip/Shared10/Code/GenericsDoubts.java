From Manish Jagnani to Everyone: (09:14 AM)
 bridge methods 

From Samriddhi Arya to Everyone: (09:14 AM)
 bridge methods 

From Akash Agarwal to Everyone: (09:14 AM)
 eraser and raw data type 

From Jatin Sharma to Everyone: (09:15 AM)
 bridge methods 

From Dishita Malav to Everyone: (09:15 AM)
 Didn’t properly understand all implications of erasure 

From Disha Goyal to Everyone: (09:15 AM)
 Class type variables are not valid in static contexts, why exactly? (Section 6.6.5) 

From DIXIT JAIN to Everyone: (09:18 AM)
 instantiation of type variables like an array 

From Harshit Mahajan to Everyone: (09:18 AM)
 bridge methods 

From Vivek Rathi to Everyone: (09:18 AM)
 Sir please explain bridge methods 

From Sahaj Jain to Everyone: (09:18 AM)
 pls brief about generics in JVM? 

From Shivnandan Mandal to Everyone: (09:18 AM)
 bridge methods 

From Rituraj Roy to Everyone: (09:18 AM)
 why can we not instantiate type variables?Did not understand the reason given 

From Disha Goyal to Everyone: (09:18 AM)
 Class type variables are not valid in static contexts, why exactly? (Section 6.6.5) 

From Jatin Sharma to Everyone: (09:18 AM)
 bridge methods 

From Hrishikesh AJ to Everyone: (09:18 AM)
 Why can't we throw and catch objects of a generic class ? 

From Manish Jagnani to Everyone: (09:18 AM)
 bridge methods 

From Aman Yadav to Everyone: (09:18 AM)
 eraseure and vridging method 

From bibhudatta panigrahi to Everyone: (09:18 AM)
 generics in jvm 

From Dishita Malav to Everyone: (09:18 AM)
 Didn’t properly understand all implications of erasure 

From Rahul Jha to Everyone: (09:18 AM)
 What is the need of '?' wildcard if we already have T. RemoveNull<T> can very well achieve what RemoveNull<?> can. 

From Dilip Suthar to Everyone: (09:18 AM)
 erasure and bridging 

From VARDHAN JAIN to Everyone: (09:18 AM)
 generics in jvm 

From Mooizz A to Everyone: (09:18 AM)
 covariance invariance 

From Samriddhi Arya to Everyone: (09:18 AM)
 bridge methods 

From vaibhav sharma to Everyone: (09:19 AM)
 variance and covariance of types 

From Anil Bansal to Everyone: (09:19 AM)
 why we cant throw generic objects 

From Kapil Dev to Everyone: (09:19 AM)
 restriction in generics and type erasure ? 

From Anirudh Goel to Everyone: (09:19 AM)
 We can't use ? as a type but T can be used. This is because T is a placeholder and ? represents any type,right?

? something // Not Possible
T something

// Following is Not Possible
 	// T[] result = new T[n];

// T will substitute at Compile Time
// 		Erase Type Also







